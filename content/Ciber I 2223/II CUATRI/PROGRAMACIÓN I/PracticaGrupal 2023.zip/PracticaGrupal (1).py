import random
import sys

class juegoAgujas:
    def __init__(self):
        self.pajar_list = []
        self.palos = None
        self.aguja = None
    
    def pajar(self):
        print("Vas a empezar a jugar a encontrar una aguja en un pajar")
        print("El número de palos en el pajar equivale a la dificultad escogida")
        print("Cuantos más palos más dificil será encontrar la aguja")
        while True:
            a1 = input("Cuántos palos quieres escoger para esta ronda: ")
            if a1.isdigit():
                a1 = int(a1)
                print("Perfecto, empezamos con " + str(a1) + " palos")
                break
            else:
                print("Parámetro incorrecto.")
        lista = []
        rand = random.randint(0, a1)
        for i in range(a1):
            lista.append("palos")
        lista.insert(rand, "aguja")
        while True:
            a2 = input("¿Dónde crees que va a estar la aguja? (Ingresa un número del 0 al " + str(a1) + "): ")
            if a2.isdigit():
                a2 = int(a2)
                if a2 == rand:
                    print("¡Muy bien, has encontrado la aguja!")
                else:
                    print("Lo siento, la aguja está en el palo " + str(rand))
                break
            else:
                print("Tiene que ser un número entero.")
    
    def jugar(self):
        while True:
            print("Bienvenido, estás en el juego de aguja en un pajar")
            print("Deberás adivinar el número que coincide con la aguja entre todos los palos")
            while True: 
                a1 = input("Pulsa 1 para jugar o pulsa 2 si quieres salir del sistema: ")
                if a1 == "1":
                    print("¡Empezamos!")
                    self.pajar()
                    break
                elif a1 == "2":
                    print("¡Hasta pronto!")
                    sys.exit()
                else:
                    print("Parámetro incorrecto")
            respuestasalirjuego=input("¿Quieres continuar jugando? y/n")
            if not respuestasalirjuego != "n":
                print("Hasta la proxima")
                break

        

p = juegoAgujas()
p.jugar()
